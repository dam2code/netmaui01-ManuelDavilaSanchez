﻿namespace WeatherClient.Models;

public enum WeatherType
{
    Sunny,
    Cloudy
}
